
function doJSFormSubmit1(theForm) {

	theForm.action = "login.pl";
	theForm.JSFormSubmit.value = "on";
	theForm.submit();

	return false;
}


function doJSFormSubmit2(theForm) {

	theForm.action = "reservations.pl";
	theForm.JSFormSubmit.value = "on";
	theForm.submit();

	return false;
}

