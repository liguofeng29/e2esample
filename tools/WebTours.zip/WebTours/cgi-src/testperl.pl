#! perl
# $Id: testperl.pl,v 1.1 2004-10-26 12:32:42 evgenyk Exp $ [MISCCSID]
print "Content-Type: text/html\n\n";
print "<HTML><BODY><H1>Hello</H1></BODY></HTML>";
exit (1);
